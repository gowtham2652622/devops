import java.util.Scanner;
class Calculator{
public static void main(String args[]){
int num1, num2, res = 0;
Scanner number = new Scanner(System.in);
Scanner operator = new Scanner(System.in);
String op;
System.out.println("Enter 1st number");
num1 = number.nextInt();
assert (num1>0): "Number should be greater than 0";
System.out.println("Enter 2nd number");
num2 = number.nextInt();
assert (num2>0): "Number should be greater than 0";
System.out.println("Enter the operators");
op = operator.nextLine();
assert ((op.equals("+")) || (op.equals("-")) || (op.equals("*")) || (op.equals("/"))): "The operator is not valid";
if (op.equals("+")){
res = num1 + num2;
}
else if (op.equals("-")){
if (num1 > num2){
res = num1 - num2;
}
else{
res = num2 - num1;
}
}
else if (op.equals("*")){
res = num1 * num2;
}
else if (op.equals("/")){
res = num1 / num2;
}
else{
System.out.println("Wrong Operator");
}
System.out.println("The Result is : " +res);
}
}
