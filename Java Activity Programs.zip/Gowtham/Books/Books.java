import java.util.*;
class Books
{
void display()
{
System.out.println("Books class");
}
}
class paperBooks extends Books
{
void display()
{
System.out.println("paperBooks class");
}
}
class mainBook
{
public static void main(String args[]){
Books B=new Books();
paperBooks PB=new paperBooks();
B=PB;
PB.display();
Books b=new Books();
B=b;
b.display();
}
}