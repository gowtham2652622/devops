import java.util.Scanner;
class Common{
int age;
String fname, lname;
public void common_details(){
Scanner S = new Scanner(System.in);
System.out.println("Student details");
System.out.println("Enter the first name");
fname = S.nextLine();
System.out.println("Enter the Last name");
lname = S.nextLine();
System.out.println("Enter the Age");
age = S.nextInt();
}
}
class Student extends Common{
int ID;
String course;
public void common_details(){
super.common_details();
Scanner S = new Scanner(System.in);
System.out.println("Cource Entrolled in");
course = S.nextLine();
System.out.println("Student id is");
ID = S.nextInt();
view1();
}
public void view1(){
System.out.println("*****Student details******");
System.out.println("First name :" +super.fname);
System.out.println("Lirst name :" +super.lname);
System.out.println("Age :" +super.age);
System.out.println("Cource Entrolled in:" +course);
System.out.println("Student ID is :" +ID);
}
}
class Employee extends Common{
int Salary,EmpID;
String dep, designation;
public void common_details(){
super.common_details();
Scanner S = new Scanner(System.in);
System.out.println("Employee Salary is :");
Salary = S.nextInt();
System.out.println("Employee Designation is :");
designation = S.nextLine();
System.out.println("Employee Department is :");
dep = S.nextLine();
System.out.println("Employee ID is :");
EmpID = S.nextInt();
view2();
}
public void view2(){
System.out.println("*****Employee details******");
System.out.println("First name :" +super.fname);
System.out.println("Lirst name :" +super.lname);
System.out.println("Age :" +super.age);
System.out.println("Employee Salary is :" + Salary);
System.out.println("Employee Designation is :" + designation);
System.out.println("Employee Department is :" + dep);
System.out.println("Employee ID is :" + EmpID);
}
}
public class Main{ 
public static void main(String args[]){
int a;
Scanner S = new Scanner(System.in);
System.out.println("1.Student details.......");
System.out.println("2.Employee details.......");
a = S.nextInt();
switch(a)
{
case 1: 
Student Stu = new Student();
Stu.common_details();
break;
case 2:
Employee emp = new Employee();
emp.common_details();
break;
default:
System.out.println("CHOOSE RIGHT OPTION");
}
}
}
