import java.util.Scanner;
import java.io.*;
public class Hangman
{

//instance variable
String word="australia";
public void showMenu()
{

int option;
Scanner sc=new Scanner(System.in);
System.out.println("1.Play");
System.out.println("2.Instructions");
System.out.println("Exit");
System.out.println("\n choose the option");
option=sc.nextInt();

//switch case
switch(option)
{
case 1:PlayGame();
           break;
case 2:InstructGame();
           break;
case 3:ExitGame();
           break;
default:System.out.println("Incorrect Menu option");
           showMenu();
           break;
}
}

//method definition
public void PlayGame()
{

//playGame functionality
int i,flag=0;
String input,guess;
Scanner sc=new Scanner(System.in);

do
{
System.out.println("\n Enter your guess:");
input=sc.nextLine();
for(i=0;i<word.length();i++)
{
if(word.charAt(i)==input.charAt(0))
{
flag=1;
}
}
if(flag==1)
{
System.out.println("This letter is present in the word");
}
else
{
System.out.println("This letter is not present in the word");
}
System.out.println("Do you want to guess again(y/n):");
guess=sc.nextLine();
flag=0;
}
while(guess.equals("y")||guess.equals("Y"));
}
public void InstructGame()
{
System.out.println("InstructGame method is invoked");
}
public void ExitGame()
{

System.out.println("ExitGame method is invoked");
System.exit(0);
}
public static void main(String[]args)
{
Hangman hg=new Hangman();
hg.showMenu();
}
}