import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class MouseMotion extends JFrame implements MouseMotionListener
{
int x , y;
JLabel position;
public MouseMotion(){
super("Mouse Motion Event");
position = new JLabel();
setLayout(new FlowLayout());
add(position);
setSize(400,500);
setVisible(true);  
}
public void MouseMotion(MouseEvent me){
x = me.getX();
y = me.getY();
position.setText("Mouse Cursor is of :" +x+""+y);
}
public void MouseDragged(MouseEvent me){
x = me.getX();
y = me.getY();
position.setText("Mouse Tragged in :" +x+""+y);
}
public static void main(String args[]){
MouseMotion obj = new MouseMotion();
}}
