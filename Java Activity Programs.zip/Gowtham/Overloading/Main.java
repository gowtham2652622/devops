import java.util.Scanner;
public abstract class Common{
public abstract void fname();
public abstract void lname();
public abstract void age();
public abstract void ID();
public class Student{
void fname(){
String fname;
System.out.println("First name is : " + fname);
}
void lname(){
String lname;
System.out.println("Last name is : " +lname);
}
void age(){
String age;
System.out.println("Age is : " + age);
}
void cource(){
String cource;
System.out.println("Cource Entrolled in : " + cource);
}
void ID(){
int ID;
System.out.println("Student id is : " + ID);
}
public class Employee extends Student{
void fname(){
String fname;
System.out.println("First name is : " + fname);
}
void lname(){
String lname;
System.out.println("Last name is : " +lname);
}
void age(){
String age;
System.out.println("Age is : " + age);
}
void Salary(){
int Salary;
System.out.println("The Salary is : " + Salary);
}
void dep(){
int Dep_name;
System.out.println("Dep name is : " + Dep_name);
}
void designation(){
int design;
System.out.println("Desigination is : " + design);
}
void ID(){
int ID;
System.out.println("Employee id is : " + ID);
}
}}}
public class Main{
public static void main(String args[]){
int a;
System.out.println("1.Student details.......");
System.out.println("2.Employee details.......");
Scanner S = new Scanner(System.in);
a = S.nextInt();
switch(a)
{
case 1: 
Student Stu = new Student();
Stu.fname();;
Stu.lname();;
Stu.age();
Stu.ID();
Stu.cource();
break;
case 2:
Employee emp = new Employee();
emp.fname();
emp.lname();
emp.age();
emp.ID();
emp.designation();
emp.dep();
emp.Salary();
break;
default:
System.out.println("CHOOSE RIGHT OPTION");
}}}
