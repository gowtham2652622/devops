import java.util.Random;

public class Motor implements Runnable {
	private int id;
	private toolbooth toll = new toolbooth();

	public Motor(int id) {
		this.id = id;

	}

	public void run() {
		System.out.println("Vehicle " + (id + 1) + " " + "Starts the journey");
		Random r = new Random();
		int rnd = r.nextInt(100);
		travel(rnd);
		System.out.println("Vehicle " + (id + 1) + " " + "Arrives the toll");
		toll.useToll(this);
		travel(rnd);
		System.out.println("Vehicle " + (id + 1) + " " + "Vehicles crossed the bridge");
	}

	public int getVehicleID() {
		return this.id;
	}

	public void travel(int time) {
		int limit = 500000;
		for (int j = 0; j < time; j++) {
			for (int k = 0; k < time; k++) {
			}
			;
		}
	}

	class toolbooth {
		boolean inUse;

		public toolbooth() {
			inUse = false;
		}

		public void useToll(Motor motors) {
			while (true) {
				if (inUse == false) {
					synchronized (this) {
						inUse = true;
						System.out.println("Vehicle " + (motors.getVehicleID() + 1) + " " + "enters toolbooth");
						motors.travel(50);
						System.out.println("Vehicle " + (motors.getVehicleID() + 1) + " " + "exit the toolbooth");
						inUse = false;
						break;
					}

				}
			}
		}
	}

	public static class Simulate {
		private static int noofVehicles = 5;
		private static Motor[] motors;

		public static void main(String args[]) {
			try {
				Simulate sm = new Simulate();
				motors = new Motor[5];
				for (int i = 0; i < noofVehicles; i++) {
					motors[i] = new Motor(i);
					Thread t = new Thread(motors[i]);
					t.start();
					Thread.sleep(10);
				}
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
	}

}