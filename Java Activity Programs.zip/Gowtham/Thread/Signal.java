import java.awt.Color;
import java.util.Random;
import javax.swing.*;

public class Signal extends Thread {
	JTextField tf;
	JLabel l;
	JFrame jf;

	public void run() {
		try {
			while (true) {
				tf.setBackground(Color.red);
				tf.setBackground(Color.GRAY);
				tf.setBackground(Color.GRAY);
				for (int i = 3; i > 0; i++) {
					String S1 = Integer.toString(i);
					tf.setText(S1);
					Thread.sleep(1000);
				}
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	public static void main(String args[]) {
		Signal Sig = new Signal();
		Thread S = new Thread(Sig);
		S.start();
	}

}
