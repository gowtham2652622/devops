
public class ThreadBasic extends Thread {
	public static void main(String args[]) {
		Thread t = Thread.currentThread();
		System.out.println("The main thread before naming is:" + t);
		t.setName("MainThread");
		System.out.println("The main thread after naming is::" + t);
		System.out.println("The system is going to sleep");
		try {
			t.sleep(10000);
		} catch (InterruptedException e) {
		}
		System.out.println("After 10 min sleep .....***.... Thread starts execting");
	}
}
