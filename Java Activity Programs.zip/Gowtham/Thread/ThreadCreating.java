import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class ThreadCreating extends Thread {
	JTextField tf;
	JLabel l;
	JFrame jf;

	public void run() {
		buildGUI();
	}

	public void display() {
		for (int i = 60; i >= 0; i--) {
			try {
				Thread.sleep(1000);
				String s = Integer.toString(i);
				tf.setText("" + s + "Seconds to go");
			} catch (Exception e) {
				System.out.println(e); // TODO: handle exception
			}
		}
		JOptionPane.showMessageDialog(jf, "Timeup");
		tf.setText("");
		tf.setEnabled(false);
	}

	public void buildGUI() {
		jf = new JFrame("Counter timer");
		JPanel p = new JPanel();
		l = new JLabel("");
		tf.setEnabled(false);
		Font f = new Font("Verdana", 0, 18);
		tf.setFont(f);
		tf.setBackground(Color.BLACK);
		p.setBackground(Color.blue);
		jf.add(p);
		p.add(tf);
		p.add(l);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(100, 3000);
		jf.setResizable(false);
		display();
	}

	public static void main(String args[]) {

		ThreadCreating C = new ThreadCreating();
		C.start();
	}
}
