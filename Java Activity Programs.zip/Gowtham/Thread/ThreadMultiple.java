import java.awt.Color;
import java.util.Random;
import javax.swing.*;

public class ThreadMultiple extends Thread {
	JLabel jl;
	JPanel l1, l2, l3;
	JFrame Jr;

	public ThreadMultiple() {
		buildGUI();
	}

	public ThreadMultiple(String s) {
		super(s);
	}

	public void run() {
		if (Thread.currentThread().getName().equals("ObstacleA")) {
			runObstacleA();
		}
		if (Thread.currentThread().getName().equals("ObstacleB")) {
			runObstacleB();
		}
		if (Thread.currentThread().getName().equals("ObstacleC")) {
			runObstacleC();
		}
	}

	public void runObstacleA() {
		Random ran = new Random();
		int s = ran.nextInt(1000);
		for (int i = -10; i < 400; i++) {
			l1.setBounds(i, s, 20, 30);
			try {
				Thread.sleep(5);
			} catch (Exception e) {
				System.out.println(e);// TODO: handle exception
			}
		}
		runObstacleC();
	}

	public void runObstacleB() {
		Random ran = new Random();
		int r = ran.nextInt(180);
		for (int i = -10; i < 400; i++) {
			l1.setBounds(i, r, 20, 20);
			try {
				Thread.sleep(11);
			} catch (Exception e) {
				System.out.println(e);// TODO: handle exception
			}
		}
		runObstacleA();
	}

	public void runObstacleC() {
		Random ran = new Random();
		int m = ran.nextInt(10);
		for (int i = -10; i < 400; i++) {
			l1.setBounds(i, m, 20, 20);
			try {
				Thread.sleep(10);
			} catch (Exception e) {
				System.out.println(e);// TODO: handle exception
			}
		}
		runObstacleB();
	}

	public void buildGUI() {
		Jr = new JFrame("Moving Objects");
		Jr.setVisible(true);
		Jr.setSize(400, 200);
		Jr.setLayout(null);
		jl = new JLabel("");
		jl.setBounds(10, 10, 400, 20);
		Jr.add(jl);
		l1 = new JPanel();
		l1.setSize(20, 20);
		l1.setBackground(Color.red);
		l1.setBounds(10, 40, 20, 20);
		Jr.add(l1);
		l2 = new JPanel();
		l2.setSize(20, 20);
		l2.setBackground(Color.blue);
		l2.setBounds(10, 80, 20, 20);
		Jr.add(l2);
		l3 = new JPanel();
		l3.setSize(20, 20);
		l3.setBackground(Color.black);
		l3.setBounds(10, 120, 20, 20);
		Jr.add(l3);
	}

	public static void main(String args[]) {
		ThreadMultiple obj = new ThreadMultiple();
		Thread Obstacle1 = new Thread(obj);
		Thread Obstacle2 = new Thread(obj);
		Thread Obstacle3 = new Thread(obj);
		Obstacle1.setName("ObstacleA");
		Obstacle2.setName("ObstacleB");
		Obstacle3.setName("ObstacleC");
		Obstacle1.start();
		Obstacle2.start();
		Obstacle3.start();
	}
}