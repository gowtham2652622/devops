import java.awt.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowContents;
public class WindowDemo extends WindowAdapter
{
JFrame jf;
public WindowDemo(){
jf = new JFrame("Window Event Demo");
jf.setSize(300,300);
jf.setVisible(true);
jf.setDefaultCloseOperation(WindowConstants.Do_Nothing_on_close);
}
public void WindowClosing(WindowEvent e){
int n = JOptionPane.showConfirmDialog(jf,"Do you want to close this window ?","Confirmation",JOptionPane.Yes_No_Cancel_Option, JOptionPane.Question_message);
if(n == JOptionPane Yes Option){
jf.dispose();
}
}
public static void main(String args[]){
WindowDemo obj = new WindowDemo();
}
}